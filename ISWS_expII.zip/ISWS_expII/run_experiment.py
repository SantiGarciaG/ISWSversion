from constants import *
from isws_exp import ISWSExp

isws_exp = ISWSExp(exp_type=EXP_TYPE)
isws_exp.run_exp()
